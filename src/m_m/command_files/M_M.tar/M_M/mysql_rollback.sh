#!/bin/bash

Now_pw=$(echo $1 | sed -e "s/+@+@+/\'/g" | sed -e 's/-@-@-/\"/g')

echo $(mysql -uroot -p${Now_pw} mysql -e "source /etc/mysql_back.d/$2")
