import os

os.system("systemctl stop mysqld > /dev/null 2>&1")
os.system("rpm -e $(rpm -qa | grep mysql) --nodeps > /dev/null 2>&1")
os.system("rm -rf /var/lib/mysql")
os.system("rm -f /var/log/mysqld.log")