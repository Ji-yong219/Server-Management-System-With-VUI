#!/bin/bash

if grep -iqw "port" /etc/my.cnf; then\
    Port=$(grep -iw "port" /etc/my.cnf | awk -F"=" '{print $NF}')

    sed -i "s/$Port/$1/g" /etc/my.cnf
    firewall-cmd --zone=public --permanent --remove-port=$Port/tcp > /dev/null 2>&1
    firewall-cmd --zone=public --permanent --add-port=$1/tcp > /dev/null 2>&1

    firewall-cmd --reload > /dev/null 2>&1
else
    sed -i "5s/^/port=$1\n/g" /etc/my.cnf
    firewall-cmd --zone=public --permanent --add-port=$1/tcp > /dev/null 2>&1
    firewall-cmd --reload > /dev/null 2>&1
fi
