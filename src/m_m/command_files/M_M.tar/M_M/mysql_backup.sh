#!/bin/bash

Now_pw=$(echo $1 | sed -e "s/+@+@+/\'/g" | sed -e 's/-@-@-/\"/g')

Date=$(date +"%Y%m%d%H%M")

if [ -d "/etc/mysql_back.d" ]; then
    mysqldump -uroot -p$Now_pw --all-databases > /etc/mysql_back.d/$Date.sql
else
    mkdir /etc/mysql_back.d
    mysqldump -uroot -p$Now_pw --all-databases > /etc/mysql_back.d/$Date.sql
fi
