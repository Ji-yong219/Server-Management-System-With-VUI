#!/bin/bash

Now_pw=$(echo $1 | sed -e "s/+@+@+/\'/g" | sed -e 's/-@-@-/\"/g')
New_pw=$(echo $2 | sed -e "s/+@+@+/\'/g" | sed -e 's/-@-@-/\"/g')

echo $(mysql -uroot -p${Now_pw} mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED BY \"$New_pw\";" 2> /dev/null)
echo $(mysql -uroot -p${New_pw} mysql -e "flush privileges;" 2> /dev/null)
