#!/bin/bash

:<<'END'
--------------------------------
$1: now passwd
$2: now mysql version
    ver: 5.7
    ver: 8.0
$3: policy number
    0. check_user_name    
    1. length    
    2. mixed_case_count
    3. number_count
    4. policy
    5. special_char_count 
$4: policy value

ex) ./mysql_policy_ch.sh Now_passwd 8 4 LOW
--------------------------------
END

Now_pw=$(echo $1 | tr "+@+@+" "\'")   #now passwd

### ver :5.7 ###
if [ $2 == 5 ]; then  
    if [ $3 == 0 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password_check_user_name=$4" 2> /dev/null)

    elif [ $3 == 2 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password_mixed_case_count=$4" 2> /dev/null)

    elif [ $3 == 3 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password_number_count=$4" 2> /dev/null)

    elif [ $3 == 4 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password_policy=$4" 2> /dev/null)

    elif [ $3 == 5 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password_special_char_count=$4" 2> /dev/null)

    elif [ $3 == 1 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password_length=$4" 2> /dev/null)

    fi

### ver :8.0 ###
elif [ $2 == 8 ]; then
    if [ $3 == 0 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password.check_user_name=$4" 2> /dev/null)

    elif [ $3 == 2 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password.mixed_case_count=$4" 2> /dev/null)

    elif [ $3 == 3 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password.number_count=$4" 2> /dev/null)

    elif [ $3 == 4 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password.policy=$4" 2> /dev/null)

    elif [ $3 == 5 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password.special_char_count=$4" 2> /dev/null)

    elif [ $3 == 1 ]; then
        echo $(mysql -uroot -p${Now_pw} mysql -e "SET GLOBAL validate_password.length=$4" 2> /dev/null)
    
    fi

fi
