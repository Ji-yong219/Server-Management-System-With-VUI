#!/bin/bash

File_name=$(echo /root/M_M/$1_security_result.log)

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : root 계정 원격 접속 제한
#중요도 : 상
#항목코드 : U-01
#----------------------------------------------------

if grep -x "PermitRootLogin no" /etc/ssh/sshd_config; then
    echo "U-01,계정관리,안전,root 계정 원격 접속 제한이 되어있습니다." > $File_name
else
    echo "U-01,계정관리,위험,root 계정 원격 접속 제한이 풀려 있습니다." > $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 패스워드 복잡성 설정
#중요도 : 상
#항목코드 : U-02
#----------------------------------------------------

#Difok=$(grep "difok" /etc/security/pwquality.conf)
Minlen=$(grep "minlen" /etc/security/pwquality.conf)
Dcredit=$(grep "dcredit" /etc/security/pwquality.conf)
Ucredit=$(grep "ucredit" /etc/security/pwquality.conf)
Lcredit=$(grep "lcredit" /etc/security/pwquality.conf)
Ocredit=$(grep "ocredit" /etc/security/pwquality.conf)

if [ $(echo "$Minlen" | awk '{print $1}') == "minlen" ]; then
    if [ $(echo "$Minlen" | awk '{print $NF}') -ge 8 ]; then
        echo "U-02,계정관리,안전,최소 패스워드 길이가 8이상으로 설정되어 있습니다." >> $File_name
    else
        echo "U-02,계정관리,위험,최소 패스워드 길이가 8이상으로 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-02,계정관리,위험,최소 패스워드 길이가 설정되어 있지않습니다." >> $File_name
fi

if [ $(echo "$Dcredit" | awk '{print $1}') == "dcredit" ]; then
    if [ $(echo "$Dcredit" | awk '{print $NF}') -eq -1 ]; then
        echo "U-02,계정관리,안전,최소 숫자 요구가 1자이상으로 설정되어 있습니다." >> $File_name
    else
        echo "U-02,계정관리,위험,최소 숫자 요구가 1자이상으로 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-02,계정관리,위험,최소 숫자 요구가 설정되어 있지않습니다." >> $File_name
fi

if [ $(echo "$Ucredit" | awk '{print $1}') == "ucredit" ]; then
    if [ $(echo "$Ucredit" | awk '{print $NF}') -eq -1 ]; then
        echo "U-02,계정관리,안전,최소 대문자 요구가 1장이상으로 설정되어 있습니다." >> $File_name
    else
        echo "U-02,계정관리,위험,최소 대문자 요구가 1장이상으로 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-02,계정관리,위험,최소 대문자 요구가 설정되어 있지않습니다." >> $File_name
fi

if [ $(echo "$Lcredit" | awk '{print $1}') == "lcredit" ]; then
    if [ $(echo "$Lcredit" | awk '{print $NF}') -eq -1 ]; then
        echo "U-02,계정관리,안전,최소 소문자 요구가 1장이상으로 설정되어 있습니다." >> $File_name
    else
        echo "U-02,계정관리,위험,최소 소문자 요구가 1장이상으로 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-02,계정관리,위험,최소 소문자 요구가 설정되어 있지않습니다." >> $File_name
fi

if [ $(echo "$Ocredit" | awk '{print $1}') == "ocredit" ]; then
    if [ $(echo "$Ocredit" | awk '{print $NF}') -eq -1 ]; then
        echo "U-02,계정관리,안전,최소 특수문자 요구가 1장이상으로 설정되어 있습니다." >> $File_name
    else
        echo "U-02,계정관리,위험,최소 특수문자 요구가 1장이상으로 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-02,계정관리,위험,최소 특수문자 요구가 설정되어 있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 계정 잠금 임계값 설정
#중요도 : 상
#항목코드 : U-03
#----------------------------------------------------

if grep -P "auth.*required.*pam_tally2.so" /etc/pam.d/system-auth | grep -qv "#" && grep -P "account.*required.*pam_tally2.so" /etc/pam.d/system-auth | grep -qv "#"; then
    if [ "$(grep "pam_tally2.so deny" /etc/pam.d/system-auth | awk -F"=" '{print $2}' | awk '{print $1}')" -le 5 ]; then
        echo "U-03,계정관리,안전,콘솔로 통한 로그인 또는 su 전환 할때 계정 잠금 임계값이 5이하의 값으로 설정 되어 있습니다." >> $File_name
    else
        echo "U-03,계정관리,위험,콘솔로 통한 로그인 또는 su 전환 할때 계정 잠금 임계값이 5이하의 값으로 설정 되어 있지않습니다." >> $File_name
    fi
else
    echo "U-03,계정관리,위험,콘솔로 통한 로그인 또는 su 전환 할때 계정 잠금 임계값이 설정 되어 있지않습니다." >> $File_name
fi

if grep -P "auth.*required.*pam_tally2.so" /etc/pam.d/password-auth | grep -qv "#" && grep -P "account.*required.*pam_tally2.so" /etc/pam.d/password-auth | grep -qv "#"; then
    if [ "$(grep "pam_tally2.so deny" /etc/pam.d/system-auth | awk -F"=" '{print $2}' | awk '{print $1}')" -le 5 ]; then
        echo "U-03,계정관리,안전,X윈도 또는 ssh원격 일때 계정 잠금 임계값이 5이하의 값으로 설정 되어 있습니다." >> $File_name
    else
        echo "U-03,계정관리,위험,X윈도 또는 ssh원격 일때 계정 잠금 임계값이 5이하의 값으로 설정 되어 있지않습니다." >> $File_name
    fi
else
    echo "U-03,계정관리,위험,X윈도 또는 ssh원격 일때 계정 잠금 임계값이 설정 되어 있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 패스워드 파일 보호
#중요도 : 상
#항목코드 : U-04
#----------------------------------------------------

if [ -e "/etc/shadow" ]; then
    if [ $(awk -F":" '{print $2}' /etc/passwd | grep -v "x" | wc -l) -eq 0 ]; then
        echo "U-04,계정관리,안전,shadow파일이 존재하고 패스워드들은 암호화되어 있습니다." >> $File_name
    else
        echo "U-04,계정관리,위험,shadow파일이 존재하지만 암호화되지 않은 패스워드가 있습니다." >> $File_name
    fi
else
    echo "U-04,계정관리,위험,shadow파일이 존재하지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : root 이외의 UID가 ‘0’ 금지
#중요도 : 중
#항목코드 : U-05
#----------------------------------------------------

if [ $(awk -F":" '{if($3==0) {print $1}}' /etc/passwd | grep -v "root" | wc -l) -eq 0 ]; then
    echo "U-05,계정관리,안전,root이외에 UID가 0인 계정은 없습니다." >> $File_name
else
    echo "U-05,계정관리,위험,root이외에 UID가 0인 계정($(awk -F":" '{if($3==0) {print $1}}' /etc/passwd | grep -v "root"))이 있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : root 계정 su 제한
#중요도 : 하
#항목코드 : U-06
#----------------------------------------------------

Group=$(ls -l /bin/su | awk '{print $4}')

if [ $Group == "wheel" ]; then
    echo "U-06,계정관리,안전,su 명령어 사용 권한이 부여되어 있는 그룹으로 설정 되어 있습니다.(현: $Group 그룹)" >> $File_name
else
    echo "U-06,계정관리,위험,su 명령어 사용 권한이 부여되어 있는 그룹으로 설정 되어있지 않습니다.(현: $Group 그룹)" >> $File_name
fi

if [ $(/root/M_M/per /bin/su) == "4750" ]; then
    echo "U-06,계정관리,안전,su 명령어의 권한이 4750으로 설정 되어 있습니다.(현: $(/root/M_M/per /bin/su) 권한)" >> $File_name
else
    echo "U-06,계정관리,위험,su 명령어의 권한이 4750으로 설정 되어 있지않습니다.(현: $(/root/M_M/per /bin/su) 권한)" >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 패스워드 최소 길이 설정
#중요도 : 중
#항목코드 : U-07
#----------------------------------------------------

Pml=$(grep "PASS_MIN_LEN" /etc/login.defs | grep -v "#" | awk '{print $2}')

if [ $Pml -ge 8 ]; then
    echo "U-07,계정관리,안전,패스워드의 최소 길이가 8이상으로 설정되어 있습니다. (현: $Pml)" >> $File_name
else
    echo "U-07,계정관리,위험,패스워드의 최소 길이가 8미만으로 설정되어 있습니다. (현: $Pml)" >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 패스워드 최대 사용기간 설정
#중요도 : 중
#항목코드 : U-08
#----------------------------------------------------

Pmd=$(grep "PASS_MAX_DAYS" /etc/login.defs | grep -v "#" | awk '{print $2}')

if [ $Pmd -le 90 ]; then
    echo "U-08,계정관리,안전,패스워드의 최대 사용기간이 90이하로 설정되어 있습니다. (현: $Pmd)" >> $File_name
else
    echo "U-08,계정관리,위험,패스워드의 최대 사용기간이 90이하로 설정되어 있습니다. (현: $Pmd)" >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 패스워드 최소 사용기간 설정
#중요도 : 중
#항목코드 : U-09
#----------------------------------------------------

Pmnd=$(grep "PASS_MIN_DAYS" /etc/login.defs | grep -v "#" | awk '{print $2}')

if [ $Pmnd -ge 1 ]; then
    echo "U-09,계정관리,안전,패스워드의 최소 사용기간이 설정되어 있습니다. (현: $Pmnd)" >> $File_name
else
    echo "U-09,계정관리,위험,패스워드의 최소 사용기간이 설정되어 있지않습니다. (현: $Pmnd)" >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 불필요한 계정 제거
#중요도 : 하
#항목코드 : U-10
#----------------------------------------------------

Count=0

for i in lp sync shutdown halt news uucp operator games gopher nfsnobody squid
do
    if grep -q "$i" /etc/passwd; then
        echo "U-10,계정관리,위험,불필요한 계정($i)이 발견되었습니다." >> $File_name
        Count=$((Count+1))
    fi
done

if [ $Count -eq 0 ]; then
    echo "U-10,계정관리,안전,불필요한 계정이 발견되지 않았습니다." >> $File_name
fi


#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 관리자 그룹에 최소한의 계정 포함
#중요도 : 하
#항목코드 : U-11
#----------------------------------------------------

U_account=$(grep "root" /etc/group | awk -F":" '{print $NF}' | grep -v "^$" | wc -l)

echo "U-11,계정관리,확인,관리자 그룹에 불필요한 계정이 $U_account개 있습니다." >> $File_name

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 계정이 존재하지 않은 GID금지
#중요도 : 하
#항목코드 : U-12
#----------------------------------------------------
User_list=(`awk -F":" '{print $1}' /etc/passwd`)
Group_act_list=(`awk -F":" '{print $NF}' /etc/group | grep -v "^$" | sort -u`)
Group_no_act=$(awk -F":" '{print $NF}' /etc/group | grep "^$" | wc -l)
Count=0

for i in ${Group_act_list[@]}
do
    if awk -F":" '{print $1}' /etc/passwd | grep -q "$i"; then
        echo "U-12,계정관리,안전,그룹에 등록되어 있는 $i계정은 존재하는 계정입니다." >> $File_name
        Count=$((Count+1))
    else
        echo "U-12,계정관리,위험,그룹에 등록되어 있는 $i계정은 존재하는 않은 계정입니다." >> $File_name
        Count=$((Count+1))
    fi
done

echo "U-12,계정관리,확인,그룹에 그룹원이 없는 그룹이 $Group_no_act개 있습니다." >> $File_name

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 동일한 UID 금지
#중요도 : 중
#항목코드 : U-13
#----------------------------------------------------

Same_uid=(`awk -F":" '{print $3}' /etc/passwd | sort | uniq -c | awk '{if($1>1) {print $2}}'`)

for i in ${Same_uid[@]}
do
    Same_uid_id=(`awk -F":" '{print $1,$3}' /etc/passwd | grep -w "$i" | awk '{print $1}'`)
    echo "U-13,계정관리,위험,${Same_uid_id[@]}계정들이 UID가 동일 합니다." >> $File_name
done

if [ ${#Same_uid[@]} -eq 0 ]; then
    echo "U-13,계정관리,안전,동일한 UID는 없습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : 사용자 shell 점검
#중요도 : 하
#항목코드 : U-14
#----------------------------------------------------

Nologin_id=$(grep -v "/sbin/nologin" /etc/passwd | wc -l)

echo "U-14,계정관리,확인,/sbin/nologin이 부여되어 있지 않은 계정이 $Nologin_id개 있습니다. 확인후 제거 바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 계정관리
#점검항목 : Session Timeout 설정
#중요도 : 하
#항목코드 : U-15
#----------------------------------------------------

if grep "TMOUT" /etc/profile | grep -qv "#"; then
    if [ $(grep "TMOUT" /etc/profile | awk -F"=" '{print $NF}') -le 600 ]; then
        echo "U-15,계정관리,안전,Session Timeout이 600초(10분) 이하로 설정 되어 있습니다." >> $File_name
    else
        echo "U-15,계정관리,위험,Session Timeout이 600초(10분) 이하로 설정 되어 있지 않습니다." >> $File_name
    fi
else
    echo "U-15,계정관리,위험,Session Timeout이 설정 되어 있지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : root 홈, 패스 디렉터리 권한 및 패스 설정
#중요도 : 상
#항목코드 : U-16
#----------------------------------------------------

for i in $(find / -name .bash_profile 2>/dev/null | grep -v "etc")
do
    if grep "PATH=" $i | awk -F"=" '{print $2}' | grep -q ":\.:"; then
        echo "U-16,파일 및 디렉터리 관리,위험,$i PATH 환경변수에 \".\"이 존재 합니다." >> $File_name
    else
        echo "U-16,파일 및 디렉터리 관리,안전,$i PATH 환경변수에 \".\"이 존재 하지 않습니다." >> $File_name
    fi
    if grep "PATH=" $i | awk -F"=" '{print $2}' | grep -q "::"; then
        echo "U-16,파일 및 디렉터리 관리,위험,$i PATH 환경변수에 \"::\"이 존재 합니다." >> $File_name
    else
        echo "U-16,파일 및 디렉터리 관리,안전,$i PATH 환경변수에 \"::\"이 존재 하지 않습니다." >> $File_name
    fi
done

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : 파일 및 디렉터리 소유자 설정
#중요도 : 상
#항목코드 : U-17
#----------------------------------------------------

Nouser_file=$(find / -nouser 2>/dev/null | wc -l)
Nogroup_file=$(find / -nogroup 2>/dev/null | wc -l)

if [ $Nouser_file -eq 0 ]; then
    echo "U-17,파일 및 디렉터리 관리,안전,소유자 nouser인 파일 및 디렉터리가 존재하지 않습니다." >> $File_name
else
    echo "U-17,파일 및 디렉터리 관리,위험,소유자 nouser 않은 파일 및 디렉터리가 $Nouser_file개 존재합니다." >> $File_name
fi


if [ $Nogroup_file -eq 0 ]; then
    echo "U-17,파일 및 디렉터리 관리,안전,소유자 nogroup인 파일 및 디렉터리가 존재하지 않습니다." >> $File_name
else
    echo "U-17,파일 및 디렉터리 관리,위험,소유자 nogroup인 파일 및 디렉터리가 $Nogroup_file개 존재합니다." >> $File_name
fi


#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /etc/passwd 파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-18
#----------------------------------------------------

if [ -e "/etc/passwd" ];then
    if [ $(ls -l /etc/passwd | awk '{print $3}') == "root" ]; then
        echo "U-18,파일 및 디렉터리 관리,안전,/etc/passwd파일의 소유자는 root가 맞습니다." >> $File_name
    else
        echo "U-18,파일 및 디렉터리 관리,위험,/etc/passwd파일의 소유자는 root가 아닙니다.(현: $(ls -l /etc/passwd | awk '{print $3}'))" >> $File_name
    fi

    if [ $(/root/M_M/per /etc/passwd) -le 644 ]; then
        echo "U-18,파일 및 디렉터리 관리,안전,/etc/passwd파일의 권한은 644이하 입니다.(현: $(/root/M_M/per /etc/passwd))" >> $File_name
    else
        echo "U-18,파일 및 디렉터리 관리,위험,/etc/passwd파일의 권한은 644이하가 아닙니다.(현: $(/root/M_M/per /etc/passwd))" >> $File_name
    fi
else
    echo "U-18,파일 및 디렉터리 관리,확인, /etc/passwd 파일이 존재 하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /etc/shadow 파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-19
#----------------------------------------------------

if [ -e "/etc/shadow" ];then
    if [ $(ls -l /etc/shadow | awk '{print $3}') == "root" ]; then
        echo "U-19,파일 및 디렉터리 관리,안전,/etc/shadow파일의 소유자는 root가 맞습니다." >> $File_name
    else
        echo "U-19,파일 및 디렉터리 관리,위험,/etc/shadow파일의 소유자는 root가 아닙니다.(현: $(ls -l /etc/shadow | awk '{print $3}'))" >> $File_name
    fi

    if [ $(/root/M_M/per /etc/shadow) -eq 400 ]; then
        echo "U-19,파일 및 디렉터리 관리,안전,/etc/shadow파일의 권한은 400 입니다.(현: $(/root/M_M/per /etc/shadow))" >> $File_name
    else
        echo "U-19,파일 및 디렉터리 관리,위험,/etc/shadow파일의 권한은 400이 아닙니다.(현: $(/root/M_M/per /etc/shadow))" >> $File_name
    fi
else
    echo "U-19,파일 및 디렉터리 관리,위험, /etc/shadow 파일이 존재 하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /etc/hosts 파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-20
#----------------------------------------------------

if [ -e "/etc/hosts" ];then
    if [ $(ls -l /etc/hosts | awk '{print $3}') == "root" ]; then
        echo "U-20,파일 및 디렉터리 관리,안전,/etc/hosts파일의 소유자는 root가 맞습니다." >> $File_name
    else
        echo "U-20,파일 및 디렉터리 관리,위험,/etc/hosts파일의 소유자는 root가 아닙니다.(현: $(ls -l /etc/hosts | awk '{print $3}'))" >> $File_name
    fi

    if [ $(/root/M_M/per /etc/hosts) -eq 600 ]; then
        echo "U-20,파일 및 디렉터리 관리,안전,/etc/hosts파일의 권한은 600 입니다.(현: $(/root/M_M/per /etc/hosts))" >> $File_name
    else
        echo "U-20,파일 및 디렉터리 관리,위험,/etc/hosts파일의 권한은 600이 아닙니다.(현: $(/root/M_M/per /etc/hosts))" >> $File_name
    fi
else
    echo "U-20,파일 및 디렉터리 관리,확인, /etc/hosts 파일이 존재 하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /etc/(x)inetd.conf 파일 소유자 권한 및 권한 설정
#중요도 : 상
#항목코드 : U-21
#----------------------------------------------------

if [ -e "/etc/inetd.conf" ];then
    if [ $(ls -l /etc/inetd.conf | awk '{print $3}') == "root" ]; then
        echo "U-21,파일 및 디렉터리 관리,안전,/etc/inetd.conf파일의 소유자는 root가 맞습니다." >> $File_name
    else
        echo "U-21,파일 및 디렉터리 관리,위험,/etc/inetd.conf파일의 소유자는 root가 아닙니다.(현: $(ls -l /etc/inetd.conf | awk '{print $3}'))" >> $File_name
    fi

    if [ $(/root/M_M/per /etc/inetd.conf) -eq 600 ]; then
        echo "U-21,파일 및 디렉터리 관리,안전,/etc/inetd.conf파일의 권한은 600 입니다.(현: $(/root/M_M/per /etc/inetd.conf))" >> $File_name
    else
        echo "U-21,파일 및 디렉터리 관리,위험,/etc/inetd.conf파일의 권한은 600이 아닙니다.(현: $(/root/M_M/per /etc/inetd.conf))" >> $File_name
    fi
else
    echo "U-21,파일 및 디렉터리 관리,확인, /etc/inetd.conf 파일이 존재 하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /etc/syslog.conf 파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-22
#----------------------------------------------------

if [ -e "/etc/syslog.conf" ];then
    if [ $(ls -l /etc/syslog.conf | awk '{print $3}') == "root" ]; then
        echo "U-22,파일 및 디렉터리 관리,안전,/etc/syslog.conf파일의 소유자는 root가 맞습니다." >> $File_name
    else
        echo "U-22,파일 및 디렉터리 관리,위험,/etc/syslog.conf파일의 소유자는 root가 아닙니다.(현: $(ls -l /etc/syslog.conf | awk '{print $3}'))" >> $File_name
    fi

    if [ $(/root/M_M/per /etc/syslog.conf) -le 644 ]; then
        echo "U-22,파일 및 디렉터리 관리,안전,/etc/syslog.conf파일의 권한은 644 이하 입니다.(현: $(/root/M_M/per /etc/syslog.conf))" >> $File_name
    else
        echo "U-22,파일 및 디렉터리 관리,위험,/etc/syslog.conf파일의 권한은 644이하가 아닙니다.(현: $(/root/M_M/per /etc/syslog.conf))" >> $File_name
    fi
else
    echo "U-22,파일 및 디렉터리 관리,확인, /etc/syslog.conf 파일이 존재 하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /etc/services 파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-23
#----------------------------------------------------


if [ -e "/etc/service" ];then
    Service_file_own=$(ls -l /etc/service | awk '{print $3}')
    if [ $service_file_own == "root" || $service_file_own == "bin" || $service_file_own == "sys" ]; then
        echo "U-23,파일 및 디렉터리 관리,안전,/etc/service파일의 소유자는 root 또는 bin,sys가 맞습니다.현($Service_file_own)" >> $File_name
    else
        echo "U-23,파일 및 디렉터리 관리,위험,/etc/service파일의 소유자는 root가 아닙니다.(현: $(ls -l /etc/service | awk '{print $3}'))" >> $File_name
    fi

    if [ $(/root/M_M/per /etc/service) -le 644 ]; then
        echo "U-23,파일 및 디렉터리 관리,안전,/etc/service파일의 권한은 644 이하 입니다(현: $(/root/M_M/per /etc/service))." >> $File_name
    else
        echo "U-23,파일 및 디렉터리 관리,위험,/etc/service파일의 권한은 644이하가 아닙니다.(현: $(/root/M_M/per /etc/service))" >> $File_name
    fi
else
    echo "U-23,파일 및 디렉터리 관리,확인, /etc/service 파일이 존재 하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : SUID,SGID,stick bit 설정 파일 점검
#중요도 : 상
#항목코드 : U-24
#----------------------------------------------------

Setuid_c=$(find / -perm -4000 2>/dev/null | wc -l)
Setgid_c=$(find / -perm -2000 2>/dev/null | wc -l)

echo "U-24,파일 및 디렉터리 관리,확인,Setuid가 걸린 파일 $Setuid_c개 발견 관리자와 상의후 주요 실행파일에만 설정바랍니다." >> $File_name
echo "U-24,파일 및 디렉터리 관리,확인,Setgid가 걸린 파일 $Setgid_c개 발견 관리자와 상의후 주요 실행파일에만 설정바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-25
#----------------------------------------------------

for i in root $(ls /home | grep -v "lost+found"); do
    for j in .bash_profile .bash_logout .bash_history .bashrc; do
        File_own=$(find / -name $j -exec ls -l {} \; 2>/dev/null | grep "$i" | grep -v "etc" | awk '{print $3}')
        File_per=$(find / -name $j -exec ls -l {} \; 2>/dev/null | grep "$i" | grep -v "etc" | awk '{print $1}')

        if [ "$File_own" == "$i" ]; then
            echo "U-25,파일 및 디렉터리 관리,안전,$i의 $j 파일의 소유자는 $File_own으로 되어 있습니다." >> $File_name
        else
            echo "U-25,파일 및 디렉터리 관리,위험,$i의 $j 파일의 소유자는 $i으로 안되어 있습니다.(현: $File_own)" >> $File_name
        fi

        if echo ${File_per:4:6} | grep -q "w"; then
            echo "U-25,파일 및 디렉터리 관리,위험,$i의 $j 파일의 소유자외의 쓰기 권한이 부여되어 있습니다.(현: $File_per)" >> $File_name
        else
            echo "U-25,파일 및 디렉터리 관리,안전,$i의 $j 파일의 소유자외의 쓰기 권한이 부여되어 있지않습니다.(현: $File_per)" >> $File_name
        fi
    done
done

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : world writeble 파일 점검
#중요도 : 상
#항목코드 : U-26
#----------------------------------------------------

W_w_file=$(find / -type f -perm -2 2>/dev/null | wc -l)

echo "U-26,파일 및 디렉터리 관리,확인,World writeble 파일이 $W_w_file개 있습니다. 불필요 시 삭제 바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : /dev에 존재하지 않은 device 파일 점검
#중요도 : 상
#항목코드 : U-27
#----------------------------------------------------

Device_unnec=$(find /dev -type f -exec ls -l {} \; 2>/dev/null | wc -l)

if [ $Device_unnec -eq 0 ]; then
    echo "U-27,파일 및 디렉터리 관리,안전,존재하지 않은 device 파일은 없습니다." >> $File_name
else
    echo "U-27,파일 및 디렉터리 관리,위험,존재하지 않은 device 파일 $Device_unnec개 있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : $HOME/.rhosts, hosts.equiv 사용 금지
#중요도 : 상
#항목코드 : U-28
#----------------------------------------------------

if [ -e "/etc/hosts.equiv" ]; then
    File_own=$(ls -l /etc/hosts.equiv | awk '{print $3}')
    File_per=$(/root/M_M/per /etc/hosts.equiv)
    if [ $File_own == "root" ]; then
        echo "U-28,파일 및 디렉터리 관리,안전,/etc/hosts.equiv의 소유자는 root입니다." >> $File_name
    else
        echo "U-28,파일 및 디렉터리 관리,위험,/etc/hosts.equiv의 소유자는 root가 아닙니다.(현: $File_own)" >> $File_name
    fi
    if [ $File_per -le 600 ]; then
        echo "U-28,파일 및 디렉터리 관리,안전,/etc/hosts.equiv의 권한이 600 이하입니다." >> $File_name
    else
        echo "U-28,파일 및 디렉터리 관리,안전,/etc/hosts.equiv의 권한이 600 이하가 아닙니다.(현: $File_per)" >> $File_name
    fi

else
    echo "U-28,파일 및 디렉터리 관리,확인,/etc/hosts.equiv 라는 파일은 없습니다." >> $File_name
fi

Rhosts_file=(`find / -name .rhosts 2>/dev/null`)

if [ ${#Rhosts_file[@]} -eq 0 ]; then
    echo "U-28,파일 및 디렉터리 관리,확인,/\$HOME/.rhosts파일들은 없습니다." >> $File_name
else
    for i in ${Rhosts_file[@]}; do
        File_own=$(ls -l $i | awk '{print $3}')
        File_per=$(/root/M_M/per $i)
        if [ $File_own == "root" ]; then
            echo "U-28,파일 및 디렉터리 관리,안전,$i의 소유자는 root입니다." >> $File_name
        else
            echo "U-28,파일 및 디렉터리 관리,위험,$i의 소유자는 root가 아닙니다.(현: $File_own)" >> $File_name
        fi
        if [ $File_per -le 600 ]; then
            echo "U-28,파일 및 디렉터리 관리,안전,$i의 권한이 600 이하입니다." >> $File_name
        else
            echo "U-28,파일 및 디렉터리 관리,안전,$i의 권한이 600 이하가 아닙니다.(현: $File_per)" >> $File_name
        fi
    done
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : 접속 IP 및 포트 제한
#중요도 : 상
#항목코드 : U-29
#----------------------------------------------------

echo "U-29,파일 및 디렉터리 관리,확인,접속을 허용할 특정 호스트에 대한 IP주소 및 포트 제한을 설정바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : hosts,lpd 파일 소유자 및 권한 설정
#중요도 : 하
#항목코드 : U-30
#----------------------------------------------------

if [ -e "/etc/hosts.lpd" ]; then
    if [ $(/root/M_M/per /etc/hosts.lpd) -eq 600 ]; then
        echo "U-30,파일 및 디렉터리 관리,안전,/etc/hosts.lpd파일의 권한은 600 입니다." >> $File_name
    else
        echo "U-30,파일 및 디렉터리 관리,위험,/etc/hosts.lpd파일의 권한은 600 이 아닙니다.(현:$(/root/M_M/per /etc/hosts.lpd))" >> $File_name
    fi
    if [ $(ls -l /etc/hosts.lpd | awk '{print $3}') == "root" ]; then
        echo "U-30,파일 및 디렉터리 관리,안전,/etc/hosts.lpd파일의 소유자는 root 입니다." >> $File_name
    else
        echo "U-30,파일 및 디렉터리 관리,위험,/etc/hosts.lpd파일의 소유자는 root가 아닙니다.(현:$(ls -l /etc/hosts.lpd | awk '{print $3}'))" >> $File_name
    fi
else
    echo "U-30,파일 및 디렉터리 관리,안전,/etc/hosts.lpd파일은 존재하지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : NIS 서비스 비활성화
#중요도 : 중
#항목코드 : U-31
#----------------------------------------------------

if ps -ef | grep ypserv | grep -qv "grep"; then
    echo "U-31,파일 및 디렉터리 관리,위험,불필요한 NIS서비스가 활성화 되어있습니다.(현:$(ps -ef | grep ypserv | grep -v "grep"))" >> $File_name
else
    echo "U-31,파일 및 디렉터리 관리,안전,불필요한 NIS서비스가 비활성화 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : UMASK 설정 관리
#중요도 : 중
#항목코드 : U-32
#----------------------------------------------------

Count=0
for i in $(grep "umask" /etc/profile | grep -v "shell" | awk '{print $2}'); do
    if [ $i -lt 022 ]; then
        echo "U-32,파일 및 디렉터리 관리,위험,UMASK가 022이상으로 설정되어 있지 않습니다." >> $File_name
        Count=$((Count+1))
    fi
done

if [ $Count -eq 0 ]; then
    echo "U-32,파일 및 디렉터리 관리,안전,UMASK가 022이상으로 설정되어 있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : 홈디렉토리 소유자 및 권한 설정
#중요도 : 중
#항목코드 : U-33
#----------------------------------------------------

for i in root $(ls /home); do
    if [ $i == "root" ]; then
        D_route=$(echo "/$i")
    else
        D_route=$(echo "/home/$i")
    fi
    D_own=$(ls -dl /$D_route | awk '{print $3}')
    D_per=$(ls -dl /$D_route | awk '{print $1}')

    if [ $D_own == "$i" ]; then
        echo "U-33,파일 및 디렉터리 관리,안전,$i의 디렉터리의 소유자는 $i입니다." >> $File_name
    else
        echo "U-33,파일 및 디렉터리 관리,위험,$i의 디렉터리의 소유자는 $i가 아닙니다.(현: $D_own)" >> $File_name
    fi

    if ! echo ${D_per:4:6} | grep -q "w"; then
        echo "U-33,파일 및 디렉터리 관리,안전,/$i의 디렉터리의 권한에 타 사용자 쓰기 권한이 부여되어 있지 않습니다." >> $File_name
    else
        echo "U-33,파일 및 디렉터리 관리,위험,/$i의 디렉터리의 권한에 타 사용자 쓰기 권한이 부여되어 있습니다." >> $File_name
    fi
done

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : 홈디렉토리로 지정한 디렉토리의 존재 관리
#중요도 : 중
#항목코드 : U-34
#----------------------------------------------------

No_home_d=$(awk -F":" '{if($6=="/") {print $1}}' /etc/passwd | wc -l)

if [ $No_home_d -eq 0 ]; then
    echo "U-34,파일 및 디렉터리 관리,안전,모든 계정에 홈 디렉터리가 존재합니다." >> $File_name
else
    echo "U-34,파일 및 디렉터리 관리,위험,홈 디렉터리가 존재하지 않은 계정이 $No_home_d개 존재합니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 파일 및 디렉터리 관리
#점검항목 : 숨겨진 파일 및 디렉토리 검색 및 제거
#중요도 : 하
#항목코드 : U-35
#----------------------------------------------------

Hide_f=$(find / -type f -name ".*" 2>/dev/null | wc -l)
Hide_d=$(find / -type d -name ".*" 2>/dev/null | wc -l)

echo "U-35,파일 및 디렉터리 관리,확인,숨겨진 파일 $Hide_f개 발견하였습니다. 의심스러운 파일은 삭제바랍니다." >> $File_name
echo "U-35,파일 및 디렉터리 관리,확인,숨겨진 디렉터리 $Hide_d개 발견하였습니다. 의심스러운 디렉터리는 삭제바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : finger 서비스 비활성화
#중요도 : 상
#항목코드 : U-36
#----------------------------------------------------

Finger_s=$(find /usr -name finger | grep -v "selinux")

if find /usr -name finger | grep -qv "selinux"; then
    echo "U-36,서비스 관리,확인,Finger가 설치되어 있습니다." >> $File_name
else
    echo "U-36,서비스 관리,확인,Finger가 설치되어 있지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : r 계열 서비스 비활성화
#중요도 : 상
#항목코드 : U-37
#----------------------------------------------------

if find / -name rlogin | grep -qv "selinux"; then
    echo "U-37,서비스 관리,위험,r계열 서비스(rlogin)가 발견되었습니다." >> $File_name
else
    echo "U-37,서비스 관리,안전,r계열 서비스(rlogin)가 발견되지않았습니다." >> $File_name
fi

if find / -name rsh | grep -qv "selinux"; then
    echo "U-37,서비스 관리,위험,r계열 서비스(rsh)가 발견되었습니다." >> $File_name
else
    echo "U-37,서비스 관리,안전,r계열 서비스(rsh)가 발견되지않았습니다." >> $File_name
fi

if find / -name rexec | grep -qv "selinux"; then
    echo "U-37,서비스 관리,위험,r계열 서비스(rexec)가 발견되었습니다." >> $File_name
else
    echo "U-37,서비스 관리,안전,r계열 서비스(rexec)가 발견되지않았습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : cron 파일 소유자 및 권한 설정
#중요도 : 상
#항목코드 : U-38
#----------------------------------------------------

for i in $(find /etc -type f -name cron* 2>/dev/null); do
    File_own=$(ls -l $i | awk '{print $3}')
    File_per=$(/root/M_M/per $i)

    if [ $File_own == "root" ]; then
        echo "U-38,서비스 관리,안전,$i파일의 소유자가 root로 되어있습니다." >> $File_name
    else
        echo "U-38,서비스 관리,위험,$i파일의 소유자가 root로 되어있지않습니다.(현:$File_own)" >> $File_name
    fi

    if [ $File_per -le 640 ]; then
        echo "U-38,서비스 관리,안전,$i파일의 권한이 640이하로 되어있습니다.(현:$File_per)" >> $File_name
    else
        echo "U-38,서비스 관리,위험,$i파일의 권한이 640이하로 되어있지않습니다.(현:$File_per)" >> $File_name
    fi

done

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : Dos 공격에 취약한 서비스 비활성화
#중요도 : 상
#항목코드 : U-39
#----------------------------------------------------

for i in echo daytime discard chargen; do
    if ! grep -qw "^$i" /etc/services; then
        echo "U-39,서비스 관리,안전,$i 서비스가 비활성화 되어있습니다." >> $File_name
    else
        echo "U-39,서비스 관리,위험,$i 서비스가 비활성화 되어있지않습니다." >> $File_name
    fi
done

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : NFS서비스 비활성화
#중요도 : 상
#항목코드 : U-40
#----------------------------------------------------

for i in nfs statd lockd; do
    if ps -ef | grep ^$i | grep -vq "grep"; then
        echo "U-40,서비스 관리,위험,$i 서비스가 비활성화 되어있지않습니다." >> $File_name
    else
        echo "U-40,서비스 관리,안전,$i 서비스가 비활성화 되어있습니다." >> $File_name
    fi
done

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : NFS 접근 통제
#중요도 : 상
#항목코드 : U-41
#----------------------------------------------------

if ps -ef | grep ^nfs | grep -vq "grep" && ps -ef | grep ^rpcbind | grep -vq "grep"; then
    if grep "*" /etc/exports; then
        echo "U-41,서비스 관리,위험,NFS서비스가 활성화 되어있으며 everyone공유로 되어있습니다." >> $File_name
    else
        echo "U-41,서비스 관리,안전,NFS서비스가 활성화 되어있지만 everyone공유로 되어있지않습니다." >> $File_name
    fi
else
    echo "U-41,서비스 관리,안전,NFS 서비스가 비활성화 되어있습니다." >> $File_name
fi


#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : automountd 제거
#중요도 : 상
#항목코드 : U-42
#----------------------------------------------------

if ps -ef | grep -iP "automountd|autofs" | grep -vq "grep"; then
    echo "U-42,서비스 관리,위험,automountd or autofs 서비스가 활성화 되어있습니다." >> $File_name
else
    echo "U-42,서비스 관리,안전,automountd or autofs 서비스가 비활성화 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : RPC 서비스 확인
#중요도 : 상
#항목코드 : U-43
#----------------------------------------------------

Count=0
for i in rpc.cmsd rpc.ttdbserverd sadmind rusersd walld sprayd rstatd rpc.nisd rexd rpc.pcnfsd rpc.statd rpc.ypupdated rpc.rquotad kcms_server cachefsd; do
    if ps -ef | grep -i "^$i" | grep -qv "grep"; then
        echo "U-43,서비스 관리,위험,$i (RPC)서비스가 활성화 되어있습니다." >> $File_name
        Count=$((Count+1))
    fi
done

if [ $Count -eq 0 ]; then
    echo "U-43,서비스 관리,안전,RPC 서비스들이 비활성화 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : NIS, NIS+ 점검
#중요도 : 상
#항목코드 : U-44
#----------------------------------------------------

Count=0
for i in ypserv ypbing ypxfrd rpc.yppasswdd rpc.ypupdated; do
    if ps -ef | grep -i "^$i" | grep -vq "grep"; then
        echo "U-44,서비스 관리,위험,$i (NIS)서비스가 활성화 되어있습니다." >> $File_name
        Count=$((Count+1))
    fi  
done

if [ $Count -eq 0 ]; then
    echo "U-44,서비스 관리,안전,NIS 서비스가 비활성화 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : tftp, talk 서비스 비활성화
#중요도 : 상
#항목코드 : U-45
#----------------------------------------------------

Count=0
for i in tftp talk ntalk; do
    if ps -ef | grep -i "^$i" | grep -vq "grep"; then
        echo "U-45,서비스 관리,위험,$i 서비스가 활성화 되어있습니다." >> $File_name
        Count=$((Count+1))
    fi  
done

if [ $Count -eq 0 ]; then
    echo "U-45,서비스 관리,안전,NIS서비스가 비활성화 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : sendmail 버전 점검
#중요도 : 상
#항목코드 : U-46
#----------------------------------------------------

if rpm -qa | grep -q "sendmail*"; then
    Ver=$(echo \$Z | /usr/sbin/sendmail -bt -d0 | grep -w "Version" | awk '{print $2}' | tr -d ".")
    if [ $Ver -lt 8152 ]; then
        echo "U-46,서비스 관리,위험,sendmail 서비스의 버전이 8.15.2이하 입니다.(현: $Ver)" >> $File_name
    else
        echo "U-46,서비스 관리,안전,sendmail 서비스의 버전이 8.15.2이상 입니다.(현: $Ver)" >> $File_name
    fi
else
    echo "U-46,서비스 관리,안전,sendmail 서비스가 설치가 되어있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : 스팸 메일 릴레이 제한
#중요도 : 상
#항목코드 : U-47
#----------------------------------------------------

if ps -ef | grep "sendmail" | grep -vq "grep"; then
    if cat /etc/mail/sendmail.cf | grep "^R$\*" | grep -q "Relaying denied"; then
        echo "U-47,서비스 관리,안전,SMTP 서비스 릴레이 제한이 설정되어 있습니다." >> $File_name
    else
        echo "U-47,서비스 관리,위험,SMTP 서비스 릴레이 제한이 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-47,서비스 관리,안전,SMTP 서비스가 비활성화가 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : 일반사용자의 Sendmail 실행 방지
#중요도 : 상
#항목코드 : U-48
#----------------------------------------------------

if ps -ef | grep "sendmail" | grep -vq "grep"; then
    Opt=$(grep -v "^*#" /etc/mail/sendmail.cf | grep PrivacyOptions | awk -F"," '{print $NF}')
    if [ $Opt == "restrictqrun" ]; then
        echo "U-48,서비스 관리,안전,일반 사용자의 Sendmail 실행 방지가 설정되어 있습니다." >> $File_name
    else
        echo "U-48,서비스 관리,위험,일반 사용자의 Sendmail 실행 방지가 설정되어있지 않습니다." >> $File_name
    fi
else
    echo "U-48,서비스 관리,안전,SMTP 서비스가 비활성화가 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : DNS 보안 버전 패치
#중요도 : 상
#항목코드 : U-49
#----------------------------------------------------

if ps -ef | grep "named" | grep -qv "grep"; then
    Ver1=$(named -v | awk '{print $2}' | awk -F"-" '{print $1}' | tr -d ".")
    Ver2=$(named -v | awk '{print $2}' | awk -F"-" '{print $2}' | awk -F"P" '{print $NF}')

    if [ $Ver1 -lt 9103 -o $Ver2 -lt 2 ]; then
        echo "U-49,서비스 관리,위험,DNS 서비스의 버전이 9.10.3-P2이하 입니다.(현: $(named -v | awk '{print $2}' | awk -F"-R" '{print $1}'))" >> $File_name
    else
        echo "U-49,서비스 관리,안전,DNS 서비스의 버전이 9.10.3-P2이상 입니다.(현: $(named -v | awk '{print $2}' | awk -F"-R" '{print $1}'))" >> $File_name
    fi
else
    echo "U-49,서비스 관리,안전,DNS 서비스가 설치가 되어있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : DNS Zone Transfer 설정
#중요도 : 상
#항목코드 : U-50
#----------------------------------------------------

if ps -ef | grep "named" | grep -vq "grep"; then
    if grep -q "allow-transfer" /etc/named.conf; then
        echo "U-50,서비스 관리,안전,DNS 서비스의 Zone Transfer를 허가된 사용자에게만 하용되어 있습니다." >> $File_name
    else
        echo "U-50,서비스 관리,위험,DNS 서비스의 Zone Transfer를 허가된 사용자에게만 하용되어 있지않습니다." >> $File_name
    fi
else
    echo "U-50,서비스 관리,안전,DNS 서비스가 비활성화 되어있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : ssh 원격접속 허용
#중요도 : 중
#항목코드 : U-51
#----------------------------------------------------

if systemctl list-unit-files | grep -qP "sshd.service.*enabled"; then
    echo "U-51,서비스 관리,안전,원격 접속시 SSH 프로토콜을 사용하고 있습니다." >> $File_name
else
    echo "U-51,서비스 관리,위험,원격 접속시 SSH 프로토콜을 사용하고 있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : at 파일 소유자 및 권한 설정
#중요도 : 중
#항목코드 : U-52
#----------------------------------------------------


if rpm -qa | grep -q "^at"; then
    At_per=$(/root/M_M/per /bin/at)
    At_own=$(ls -l /bin/at | awk '{print $3}')
    At_deny_per=$(/root/M_M/per /etc/at.deny)
    At_deny_own=$(ls -l /etc/at.deny | awk '{print $3}')

    if [ $At_per -lt 640 ]; then
        echo "U-52,서비스 관리,안전,/bin/at명령어의 권한이 640이하 입니다.(현: $At_per)" >> $File_name
    else
        echo "U-52,서비스 관리,위험,/bin/at명령어의 권한이 640이하가 아닙니다.(현: $At_per)" >> $File_name
    fi

    if [ $At_own == "root" ]; then
        echo "U-52,서비스 관리,안전,/bin/at명령어의 소유자가 root 입니다." >> $File_name
    else
        echo "U-52,서비스 관리,위험,/bin/at명령어의 소유자가 root가 아닙니다.(현:$At_own)" >> $File_name
    fi

    if [ $At_deny_per -lt 640 ]; then
        echo "U-52,서비스 관리,안전,/etc/at.deny파일의 권한이 640이하 입니다.(현: $At_deny_per)" >> $File_name
    else
        echo "U-52,서비스 관리,안전,/etc/at.deny파일의 권한이 640이하가 아닙니다.(현: $At_deny_per)" >> $File_name
    fi

    if [ $At_deny_own == "root" ]; then
        echo "U-52,서비스 관리,안전,/etc/at.deny파일의 소유자가 root 입니다." >> $File_name
    else
        echo "U-52,서비스 관리,위험,/etc/at.deny파일의 소유자가 root가 아닙니다.(현:$At_deny_own)" >> $File_name
    fi
else
    echo "U-52,서비스 관리,안전,at데몬이 설치 되어 있지 않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : SNMP 서비스 구동 점검
#중요도 : 중
#항목코드 : U-53
#----------------------------------------------------

if ps -ef | grep snmp | grep -qv "grep"; then
    echo "U-53,서비스 관리,위험,SNMP 서비스를 사용하고 있습니다." >> $File_name
else
    echo "U-53,서비스 관리,안전,SNMP 서비스를 사용하고 있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : SNMP 서비스 커뮤니티스트링의 복잡성 설정
#중요도 : 중
#항목코드 : U-54
#----------------------------------------------------

if ps -ef | grep snmp | grep -qv "grep"; then
    Snmp_name=$(grep "^com2sec" /etc/snmp/snmpd.conf | awk '{print $NF}')
    if echo $Snmp_name | grep -qP "public|private"; then
        echo "U-54,서비스 관리,위험,SNMP Community 이름이 $Snmp_name입니다." >> $File_name
    else
        echo "U-54,서비스 관리,위험,SNMP Community 이름이 public or private이 아닙니다.(현: $Snmp_name)" >> $File_name
    fi
else
    echo "U-54,서비스 관리,안전,SNMP 서비스를 사용하고 있지않습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : NFS설정파일 접근권한
#중요도 : 중
#항목코드 : U-55
#----------------------------------------------------

if [ -e "/etc/exports" ]; then
    Exports_per=$(/root/M_M/per /etc/exports)
    Exports_own=$(ls -l /etc/exports | awk '{print $3}')

    if [ $Exports_per -le 644 ]; then
        echo "U-55,서비스 관리,안전,NFS 접근제어 설정파일의 권한이 644이하 입니다.(현: $Exports_per)" >> $File_name
    else
        echo "U-55,서비스 관리,위험,NFS 접근제어 설정파일의 권한이 644이하가 아닙니다.(현: $Exports_per)" >> $File_name
    fi
 
    if [ $Exports_own == "root" ]; then
        echo "U-55,서비스 관리,안전,NFS 접근제어 설정파일의 소유자가 root 입니다." >> $File_name
    else
        echo "U-55,서비스 관리,위험,NFS 접근제어 설정파일의 소유자가 root가 아닙니다.(현: $Exports_own)" >> $File_name
    fi
else
    echo "U-55,서비스 관리,확인,/etc/exports 파일이 없습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : expn, vrfy 명령어 제한
#중요도 : 중
#항목코드 : U-56
#----------------------------------------------------

if ps -ef | grep "sendmail" | grep -vq "grep"; then
    if grep "PrivacyOption" /etc/mail/sendmail.cf | grep -q "novrfy"; then
        echo "U-56,서비스 관리,안전,SMTP 서비스에 novrfy옵션이 설정되어 있습니다." >> $File_name
    else
        echo "U-56,서비스 관리,위험,SMTP 서비스에 novrfy옵션이 설정되어 있지않습니다." >> $File_name
    fi

    if grep "PrivacyOption" /etc/mail/sendmail.cf | grep -q "noexpn"; then
        echo "U-56,서비스 관리,안전,SMTP 서비스에 noexpn옵션이 설정되어 있습니다." >> $File_name
    else
        echo "U-56,서비스 관리,위험,SMTP 서비스에 noexpn옵션이 설정되어 있지않습니다." >> $File_name
    fi
else
    echo "U-56,서비스 관리,안전,SMTP 서비스가 비활성화가 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : Telnet 서비스 비활성화
#중요도 : 상
#항목코드 : U-57
#----------------------------------------------------

if systemctl list-units --state=active | grep -q "telnet"; then
    echo "U-57,서비스 관리,위험,Telnet서비스가 활성화 되어있습니다." >> $File_name
else
    echo "U-57,서비스 관리,안전,Telnet서비스가 비활성화 되어있습니다." >> $File_name
fi


#----------------------------------------------------
#분류 : 서비스 관리
#점검항목 : Sftp를 제외한 ftp서비스 비활성화
#중요도 : 상
#항목코드 : U-58
#----------------------------------------------------

Ftp_list=(`systemctl list-unit-files | grep ftpd.service | awk '{print $1}' | tr "\n" " "`)

if [ ${#Ftp_list[@]} -eq 0 ]; then
    echo "U-58,서비스 관리,안전,sftp를 제외한 ftp서비스가 설치 되어있지않습니다." >> $File_name
else
    echo "U-58,서비스 관리,위험,sftp를 제외한 ${Ftp_list[@]} 설치 되어있습니다." >> $File_name
fi

#----------------------------------------------------
#분류 : 패치 관리
#점검항목 : 최신 보안패치 및 벤더 권고사항 적용
#중요도 : 상
#항목코드 : U-59
#----------------------------------------------------

echo "U-59,패치 관리,확인,주기적으로 시스템을 최신버전으로 패치하기 바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 로그 관리
#점검항목 : 로그의 정기적 검토 및 보고
#중요도 : 상
#항목코드 : U-60
#----------------------------------------------------

echo "U-60,로그 관리,확인,로그 기록에 대해 정기적으로 검토 분석 리포트 작성 및 보고등의 조치 바랍니다." >> $File_name

#----------------------------------------------------
#분류 : 로그 관리
#점검항목 : 정책에 따른 시스템 로깅 설정
#중요도 : 상
#항목코드 : U-61
#----------------------------------------------------

Count=0
if grep -qP "^\*\.info\;mail\.none\;authpriv\.none\;cron\.none.*\/var\/log\/messages" /etc/rsyslog.conf; then
    Count=$((Count+1))
else
    echo "U-61,로그 관리,위험,/etc/rsyslog.conf파일 안에 *.info;mail.none;authpriv.none;cron.none. or /var/log/messages 가 포함되어 있지않습니다." >> $File_name
fi

if grep -qP "^authpriv\.\*.*\/var\/log\/secure" /etc/rsyslog.conf; then
    Count=$((Count+1))
else
    echo "U-61,로그 관리,위험,/etc/rsyslog.conf파일 안에 authpriv.* or /var/log/secure 가 포함되어 있지않습니다." >> $File_name
fi

if grep -qP "^mail\.\*.*\/var\/log\/maillog" /etc/rsyslog.conf; then
    Count=$((Count+1))
else
    echo "U-61,로그 관리,위험,/etc/rsyslog.conf파일 안에 mail.* or /var/log/maillog 가 포함되어 있지않습니다." >> $File_name
fi

if grep -qP "^cron\.\*.*\/var\/log\/cron" /etc/rsyslog.conf; then
    Count=$((Count+1))
else
    echo "U-61,로그 관리,위험,/etc/rsyslog.conf파일 안에 cron.* or /var/log/cron 이 포함되어 있지않습니다." >> $File_name
fi

if grep -qP "^\*\.alert.*^\/dev\/console" /etc/rsyslog.conf; then
    Count=$((Count+1))
else
    echo "U-61,로그 관리,위험,/etc/rsyslog.conf파일 안에 *.alert or /dev/console 이 포함되어 있지않습니다." >> $File_name
fi

if grep -qP "^\*\.emerg.*\*" /etc/rsyslog.conf; then
    Count=$((Count+1))
else
    echo "U-61,로그 관리,위험,/etc/rsyslog.conf파일 안에 *.emerg, or, * 가 포함되어 있지않습니다." >> $File_name
fi

if [ $Count -eq 6 ]; then
    echo "U-61,로그 관리,안전,로그 기록 정책이 정책에 따라 설정되어 수립되어 있으며 보안정책에 따라 로그를 남기고 있습니다." >> $File_name
fi

S=$(awk -F"," '{if ($3=="안전") {print $3}}' $File_name | wc -l) #안전
C=$(awk -F"," '{if ($3=="확인") {print $3}}' $File_name | wc -l) #확인
W=$(awk -F"," '{if ($3=="위험") {print $3}}' $File_name | wc -l) #위홈

sed -i "1s/^/$S,$C,$W\n/g" $File_name  #안전,확인,위험

