#!/bin/bash

SSH_PORT_1=$(grep -wi "^Port" /etc/ssh/sshd_config | awk '{print $2}')
SSH_PORT_2=$(grep -wi "^#Port" /etc/ssh/sshd_config | awk '{print $2}')

if [ ${#SSH_PORT_1} -gt 0  ]; then
    command="sed -i 's/$SSH_PORT_1/$1/' /etc/ssh/sshd_config"
    eval $command
    firewall-cmd --zone=public --permanent --remove-port=$SSH_PORT_1/tcp > /dev/null 2>&1
    firewall-cmd --zone=public --permanent --add-port=$1/tcp > /dev/null 2>&1
    firewall-cmd --reload > /dev/null 2>&1
    systemctl restart sshd

elif [ ${#SSH_PORT_2} -gt 0 ]; then
    command="sed -i 's/$(grep -wi "^#Port" /etc/ssh/sshd_config)/Port $1/' /etc/ssh/sshd_config"
    eval $command
    firewall-cmd --zone=public --permanent --remove-port=$SSH_PORT_2/tcp > /dev/null 2>&1
    firewall-cmd --zone=public --permanent --add-port=$1/tcp > /dev/null 2>&1
    firewall-cmd --reload > /dev/null 2>&1
    systemctl restart sshd

else
    command="sed -i '17s/^/Port $1\n/' /etc/ssh/sshd_config"
    eval $command
    firewall-cmd --zone=public --permanent --add-port=$1/tcp > /dev/null 2>&1
    firewall-cmd --reload > /dev/null 2>&1
    systemctl restart sshd
    
fi


