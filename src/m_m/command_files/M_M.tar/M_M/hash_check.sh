#!/bin/bash

exec 3<>/dev/tcp/lion.cju.ac.kr/$1

File_name=(`cat ~/hashcode | awk '{print $2}'`)
File_hash=(`cat ~/hashcode | awk '{print $1}'`)

for i in ${!File_name[@]}; do
    Hash=$(sha256sum ~/M_M/${File_name[$i]} | awk '{print $1}')

    if [ ${File_hash[$i]} != $Hash ]; then
        echo "0" >&3
        exit

    fi
done
echo "1" >&3
